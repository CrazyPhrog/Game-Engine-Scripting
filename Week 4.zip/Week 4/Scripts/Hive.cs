using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Hive : MonoBehaviour
{
    public GameObject beePrefab; // Reference to the bee prefab
    public int startingBees = 3; // Starting number of bees
    public float honeyProductionRate = 10f; // Time in seconds to produce honey
    public int maxNectarCapacity = 10; // Maximum capacity of nectar storage

    private int currentBees; // Current number of bees in the hive
    private int nectarAmount; // Current amount of nectar stored in the hive
    private int honeyAmount; // Current amount of honey produced by the hive
    private float honeyProductionTimer; // Timer for honey production

    void Start()
    {
        // Instantiate bees and initialize hive variables
        currentBees = startingBees;
        honeyProductionTimer = honeyProductionRate;
        InstantiateBees();
    }

    void Update()
    {
        // Check if there is nectar stored and if the hive should produce honey
        if (nectarAmount > 0 && honeyProductionTimer > 0)
        {
            honeyProductionTimer -= Time.deltaTime;
            if (honeyProductionTimer <= 0)
            {
                ProduceHoney();
            }
        }
    }

    void InstantiateBees()
    {
        // Instantiate bees based on the starting number
        for (int i = 0; i < startingBees; i++)
        {
            CreateBee();
        }
    }

    void CreateBee()
    {
        // Instantiate a new bee prefab and initialize it with the hive reference
        GameObject newBee = Instantiate(beePrefab, transform.position, Quaternion.identity);
        Bee beeScript = newBee.GetComponent<Bee>();
        if (beeScript != null)
        {
            beeScript.Init(this);
        }
    }

    void ProduceHoney()
    {
        // Produce honey and consume nectar
        honeyAmount++;
        nectarAmount--;
        honeyProductionTimer = honeyProductionRate;

        // Check if there is more nectar to continue honey production
        if (nectarAmount > 0)
        {
            honeyProductionTimer = honeyProductionRate;
        }
    }

    public void GiveNectar()
    {
        // Receive nectar from bees
        nectarAmount++;

        // Start honey production countdown if not already counting down
        if (honeyProductionTimer <= 0 && nectarAmount > 0)
        {
            honeyProductionTimer = honeyProductionRate;
        }
    }
}

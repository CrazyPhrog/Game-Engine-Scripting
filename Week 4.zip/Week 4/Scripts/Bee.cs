using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Bee : MonoBehaviour
{
    private Hive hive; // Reference to the hive that created the bee

    void Start()
    {
        // Initialize the bee's behavior
        CheckAnyFlower();
    }

    public void Init(Hive hive)
    {
        // Assign the hive that created the bee
        this.hive = hive;
    }

    void CheckAnyFlower()
    {
        // Find a flower to check for nectar
        Flower[] flowers = GameObject.FindObjectsOfType<Flower>();
        if (flowers.Length > 0)
        {
            // Pick a random flower
            Flower randomFlower = flowers[Random.Range(0, flowers.Length)];

            // Fly to the flower
            transform.DOMove(randomFlower.transform.position, 1f).OnComplete(() =>
            {
                // Check if the flower has nectar
                if (randomFlower.CheckForNectar())
                {
                    // If flower returned nectar, go back to the hive and give nectar
                    ReturnToHive(randomFlower);
                }
                else
                {
                    // If flower did not return nectar, check another flower
                    CheckAnyFlower();
                }
            }).SetEase(Ease.Linear);
        }
        else
        {
            // No flowers found, bee can't do anything
            Debug.LogWarning("No flowers found in the scene.");
        }
    }

    void ReturnToHive(Flower flower)
    {
        // Fly to the hive
        transform.DOMove(hive.transform.position, 1f).OnComplete(() =>
        {
            // Give nectar to the hive
            hive.GiveNectar(); // Corrected method call

            // After giving nectar, go and try to collect nectar from more flowers
            CheckAnyFlower();
        }).SetEase(Ease.Linear);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Flower : MonoBehaviour
{
    public float nectarProductionRate = 10f; // Rate of nectar production
    public Color nectarReadyColor; // Color when nectar is ready
    public Color noNectarColor; // Color when no nectar is available

    private bool hasNectar = false; // Flag to track if the flower has nectar
    private float nectarCountdown; // Countdown timer for nectar production

    void Start()
    {
        // Start countdown for nectar production
        nectarCountdown = nectarProductionRate;
    }

    void Update()
    {
        // Check if the flower has nectar
        if (!hasNectar)
        {
            // Count down to produce nectar
            nectarCountdown -= Time.deltaTime;
            if (nectarCountdown <= 0)
            {
                ProduceNectar();
            }
        }
    }

    void ProduceNectar()
    {
        // Produce nectar and reset countdown
        hasNectar = true;
        nectarCountdown = nectarProductionRate;

        // Change flower color to nectar ready color
        GetComponent<SpriteRenderer>().color = nectarReadyColor;
    }

    public bool CheckForNectar()
    {
        // Check if the flower has nectar
        return hasNectar;
    }

    public bool TakeNectar()
    {
        // If flower has nectar, take it and reset nectar status
        if (hasNectar)
        {
            hasNectar = false;
            GetComponent<SpriteRenderer>().color = noNectarColor; // Change color back to default
            return true;
        }
        else
        {
            return false;
        }
    }
}
